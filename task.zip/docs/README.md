# Word

[Informe](https://docs.google.com/document/d/1VlxaJFOuje98KY-IT3URwzgPeDRnQMs_72Pjv4_Syfs/edit?usp=sharing)
