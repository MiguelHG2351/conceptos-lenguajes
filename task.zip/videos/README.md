[video del proyecto](https://youtu.be/Ird8RqzDpXk)

# El video de paradigma de programacion.mp4 son los slides