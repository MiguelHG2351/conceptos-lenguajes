
class Saludos {
    saludar(name) {
        console.log(`Hola, ${name}`)
    }
}

export default Saludos