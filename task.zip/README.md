# Nombre

Miguel Angel Hernández Gaitan

# Files

- eventos.js

muestra un ejemplo de programación de eventos

- imperativa

muestra un ejemplo de programación imperativa

- logica

Programación lógica, ejemplo matematico. Se extraen los datos de una imagen con canvas para generar un degradadp pero faltan archivos

- POO

Ejemplo de programación orientada a objetos, clases, prototipos, Herencia, promesas.

- modulos.js

Ejemplo de modularización y programación modular

- reactjs_funcional y reactjs_object

Ejemplos de como los frameworks pueden ser multiparadigma

# Recursos en google docs

[Informe](https://docs.google.com/document/d/1VlxaJFOuje98KY-IT3URwzgPeDRnQMs_72Pjv4_Syfs/edit?usp=sharing)


# Recursos Video

[Presentación en canvas](https://www.canva.com/design/DAEG1b2nlMM/-lIrfhOU7JNhFOSJr7u7Vg/view?utm_content=DAEG1b2nlMM&utm_campaign=designshare&utm_medium=link&utm_source=sharebutton)

[Presentación en video](./videos/Paradigmas_de_programación.mp4)

# Video de la tarea

()[]

Esta mejor explicado en el informe por que en el video esta algo nerviso